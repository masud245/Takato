TAKA EARN BD - RENDER STATIC SITE

Files:
- index.html: Main website file.

Render settings:
- Create: New + Static Site
- Connect the GitHub repository containing this file.
- Branch: main (or your actual branch)
- Root Directory: leave blank IF index.html is in the repository root.
- Build Command: leave blank
- Publish Directory: .

IMPORTANT:
This package is a static front-end website. Features that save data in browser Local Storage remain on that browser/device only. Admin changes will NOT automatically sync to all visitors. For shared accounts, quiz scheduling, balances, withdrawals, or secure admin controls, connect a backend/database (for example Supabase/Firebase) and implement server-side security.

If you upload the contents of this folder into a GitHub repository subfolder instead of the repository root, set Root Directory to that subfolder name.
